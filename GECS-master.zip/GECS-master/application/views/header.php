<html>
	<body>
	<h1> DEPARTMENT OF HEAVY INDUSTRY</h1>
	<h2> Gst Exemtion Certficate Scheme </h2>
	</body>
	
</html>
	
	
